import { View, Text } from 'react-native'
import React from 'react'

export default function discover() {
  return (
    <View>
      <Text>discover</Text>
    </View>
  )
}