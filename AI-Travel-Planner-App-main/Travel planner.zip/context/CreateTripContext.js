import { createContext } from "react";

export const CreateTripContext=createContext(null);